let a = 8;
let b = 7;
let plus = a + b;
console.log(plus);
let minus = a - b;
console.log(minus)
