let budi = 20;
let randi = 10;
let operate = 13;
let trouble = 7;

for (let angkot = 1; angkot <= operate; angkot++){
    console.log("Angkot Budi no."+angkot+" sedang beroperasi");
}console.log("\n")

for(let angkot = 14; angkot <= budi; angkot++){
    console.log("Angkot Budi no."+angkot+" sedang dipinjam Randi");
}console.log("\n")

for(let angkot = 1; angkot <= trouble; angkot++){
    console.log("Angkot Randi no."+angkot+" sedang rusak");
}console.log("\n")

for(let angkot = 8; angkot <= randi; angkot++){
    console.log("Angkot Randi no."+angkot+" sudah dijual");
}