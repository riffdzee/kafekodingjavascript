for(let a = 0; a <= 10; a++){
    console.log("For ke-"+a)
}

