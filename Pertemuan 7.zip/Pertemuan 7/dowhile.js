a=0;
do{
    console.log("Do While ke-"+a);a++
}while(a<=10)