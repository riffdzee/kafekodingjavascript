a = 0;
while (a<=10){
    console.log("While ke-"+a);a++
}
