let room =1
let available=20
let full = 8
while (room <= full){
    console.log("Kamar 2-"+room+" sedang penuh.");room++
}console.log("\n")

for (let room=6; room <= available; room++){
    console.log("Kamar 3-"+room+" sedang kosong.")
}
