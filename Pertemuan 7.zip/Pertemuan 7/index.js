a=20
while(a<=50){
    console.log("Kamar 2-"+a+" sedang penuh.");a++
}console.log("\n")

a=20
do{
    console.log("Kamar 3-"+a+" sedang penuh.");a++
}while(a<=50);console.log("\n")

for(let a = 20; a <= 50; a++){
    console.log("Kamar 4-"+a+" sedang penuh.")
}

