var kegiatan = "Latihan";

/*
Perkenalan diri kalian
Buat variabel berisi data diri (nama, jurusan, alamat, kelas yang dimasuki, hobi)
Variasikan jenis variabel (var, let, const)
*/

var nama = "Muhammad Rifki Fayzi";
let jurusan = "Sistem Informasi";
const nim = "245720111039";
let alamat = "Lubuk Basung";
const kelaskafekoding = "Javascript";
let hobi = "Main Basket";

console.log(kegiatan);