function a(){
    const n = 1;
    console.log(n);
}

a();

function duo(){
    const mhs = ['agus', 'ega', 'dodi'];
    const n = 2;
    const kota = ['jakarta', 'yogyakarta'];
    return  kota, n, mhs;
}

console.log(duo());

function plus(num1, num2){
    return num1+num2;
}

console.log(plus(3,4))