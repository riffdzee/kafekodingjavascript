function segitiga(alas, tinggi){
    const luas = alas*tinggi/2;
    console.log(luas);
}

segitiga(3, 5);

function persegi(sisi){
    const luas = sisi*sisi;
    console.log(luas);
}

persegi(8);

function rectangle(panjang, lebar){
    const luas = panjang * lebar;
    console.log(luas);
}

rectangle(4, 6);

function circle(jarijari){
    const luas = 3.14*jarijari*jarijari;
    console.log(luas);
}

circle(7);