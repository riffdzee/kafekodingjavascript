let pay = 15000;
if (pay >= 10000){
    console.log("Selamat, anda mendapatkan hadiah!");
}else {
    console.log("Terima kasih sudah berbelanja.");
}

const username = "admin";
const password = "123";
if (username == "admin" && password == "123"){
    console.log("Berhasil!");
}else{
    console.log("Coba Lagi");
}

let score = 60;
if(score > 90){
    console.log("Nilai = A");
}else if(score >= 80){
    console.log("Nilai = B");
}else if(score >= 70){
    console.log("Nilai = c");
}else if(score >= 50){
    console.log("Nilai = D");
}else{
    console.log("Nilai = E");
}

let nilai = 90;
if (nilai >= 90){
    console.log("Nilai = A");
}else if (nilai >= 80){
    console.log("Nilai = B");
}else{
    console.log("Nilai = C");
}