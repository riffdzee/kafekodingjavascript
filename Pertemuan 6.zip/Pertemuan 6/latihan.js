//carilah luas segitiga dari :
//alas 12
//tinggi 7
let alas = 12;
let tinggi = 7;
console.log(alas*tinggi/2);
