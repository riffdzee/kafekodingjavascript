let x = 11+"Asep";
let = bool = 1;

console.log(5>8);