//Jawaban
//1. Jelaskan apa itu Variabel!
const variabel = "1. Variabel adalah identifikasi/wadah untuk menyimpan nilai data ke dalam komputer.";
console.log (variabel);
//2. Jelaskan apa itu Tipe Data!
const tipedata = "2. Tipe Data adalah pengklasifikasian data berdasarkan jenis data yang dimasukkan.";
console.log (tipedata);

//Data diri
const nama = "Muhammad Rifki Fayzi";
console.log(nama);
let panggilan = "Rifki, Iki, Kiki, Riff";
console.log(panggilan);
const nim = 245720111039;
console.log(nim);
let umur = 21;
console.log(umur, "tahun");
const asalsekolah = "SMK Negeri 1 Cibinong";
console.log(asalsekolah);
let kelas = "Javascript";
console.log(kelas);
let x = true;
let y = false;
console.log("Apakah saya perempuan(?) =", x && y);