var kelas = "javascript";
let mahasiswa = "Riff";
const jurusan = "Sistem Informasi";
console.log(mahasiswa);