let age = 16;
let result = (age >= 18) ? "You're eligible to drive a vehicle" : "You're not eligible to drive a vehicle";
console.log(result);

let her = "mycriteria";
let opinion = (her=="mycriteria") ? "I want to be ur boyfriend" : "I didn't want to be ur boyfriend";
console.log(opinion);