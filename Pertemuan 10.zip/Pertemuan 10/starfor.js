let hasil = "";
for (a=1; a<=5; a--){
    for(b=a; b<=5; b--){
        hasil += "* ";
    }hasil += "\n";
}console.log(hasil)