const keluarga = [ 'Budi Sudarsono','Ayu Sinta Putri',['Joko','Dina','April','Alif','Doni'] ];

console.log(keluarga[2][2]+' adalah anak dari '+keluarga[1]);

console.log(keluarga[2][4]+' adalah anak ke-5 dari '+keluarga[1]);
